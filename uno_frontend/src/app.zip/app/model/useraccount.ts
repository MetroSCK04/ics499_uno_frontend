export class Useraccount {
     username: String='';
	 email: String='';
	 password: String='';
}
