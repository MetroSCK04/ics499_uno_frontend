import { Card } from './card';

export class Hand {
    cards: Card[] = [];
}