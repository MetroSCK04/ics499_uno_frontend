import { Hand } from './hand';

describe('Hand', () => {
  it('should create an instance', () => {
    expect(new Hand()).toBeTruthy();
  });
});
