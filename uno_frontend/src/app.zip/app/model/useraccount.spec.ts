import { Useraccount } from './useraccount';

describe('Useraccount', () => {
  it('should create an instance', () => {
    expect(new Useraccount()).toBeTruthy();
  });
});
