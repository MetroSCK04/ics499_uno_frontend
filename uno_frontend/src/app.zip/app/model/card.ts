export class Card {
    cardID?: number;
    color: string;
    num: number;
  
    constructor(color: string, num: number) {
      this.color = color;
      this.num = num;
    }
  }
  